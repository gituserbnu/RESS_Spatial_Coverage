function [area_greddy,removedNodes] = greedyReduceCoverage(G, nodePositions)
    % G是邻接矩阵，nodePositions是节点的位置矩阵，每行为一个节点的[x, y]坐标
    % maxRemove是最多移除节点的数量
    % removedNodes记录被移除的节点索引
    % finalArea是最终的最大连通片的覆盖范围
   

     area_0 = calculateLargestComponentCoverage(G, nodePositions);
    n = size(G, 1); % 网络中的节点总数
    N=n;
    maxRemove=n;
    removedNodes = []; % 初始化移除节点的列表
    currentG = G; % 当前网络的邻接矩阵
    
    for i = 1:maxRemove
        i
        maxAreaReduction = -inf; % 初始化最大面积降低量
        nodeToRemove = 0; % 初始化要移除的节点索引
        for j = 1:n
         
            if ~ismember(j, removedNodes)
                % 尝试移除节点j
                tempG = currentG;
                del=union(j,removedNodes);
                tempG(del, :) = [];
                tempG(:, del) = [];
                tempNodePositions = nodePositions;
                tempNodePositions(del, :) = [];
                
                % 计算移除后的覆盖范围
                tempArea = calculateLargestComponentCoverage(tempG, tempNodePositions);
                areaReduction = calculateLargestComponentCoverage(currentG, nodePositions) - tempArea;
                
                % 更新最大面积降低量和对应的节点
                if areaReduction > maxAreaReduction
                    maxAreaReduction = areaReduction;
                    nodeToRemove = j;
                end
            end
        
        end
        
        % 移除影响最大的节点
        if nodeToRemove > 0
            removedNodes = [removedNodes, nodeToRemove];

        else
            break; % 如果没有节点可以被移除，则退出循环
        end
    end

   I=removedNodes;
for i=1:N
   % i
    G2=G;
    nodePositions_temp=nodePositions;
    attack=I(1:i);
    G2(attack,:)=[];
    G2(:,attack)=[];
    nodePositions_temp(attack,:)=[];
   area_greddy(i) = calculateLargestComponentCoverage(G2, nodePositions_temp);
end
area_greddy=area_greddy/area_0;

