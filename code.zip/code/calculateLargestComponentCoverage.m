function area = calculateLargestComponentCoverage(G, nodePositions)
    % G是邻接矩阵，nodePositions是节点的位置矩阵，每行为一个节点的[x, y]坐标

    % 计算网络的连通组件
    [S, C] = graphconncomp(sparse(G), 'Directed', false);
    
    % 找到最大连通片
    largestComponentSize = 0;
    largestComponent = 1;
    for i = 1:S
        componentSize = sum(C == i);
        if componentSize > largestComponentSize
            largestComponentSize = componentSize;
            largestComponent = i;
        end
    end
    
    % 获取最大连通片的节点位置
    largestComponentPositions = nodePositions(C == largestComponent, :);
    
if size(largestComponentPositions, 1) < 3
        % 点数不足以形成凸包，返回面积为0
        area = 0;
else
    % 计算最小凸包的顶点
    k = convhull(largestComponentPositions(:,1), largestComponentPositions(:,2));  
    % 计算最小凸包的面积
    area = polyarea(largestComponentPositions(k,1), largestComponentPositions(k,2));
end
