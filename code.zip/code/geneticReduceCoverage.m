function [area_ga, removedNodes] = geneticReduceCoverage(G, nodePositions, populationSize, maxGenerations, mutationRate)
    % G是邻接矩阵，nodePositions是节点的位置矩阵，每行为一个节点的[x, y]坐标
    % populationSize是种群规模
    % maxGenerations是最大迭代次数
    % mutationRate是变异概率
    

    d=degree(G);
    n = size(G, 1); % 网络中的节点总数
    area_0 = calculateLargestComponentCoverage(G, nodePositions);

    % 初始化输出变量
    area_ga = zeros(1, n);
    removedNodes = cell(1, n);
    
    

    for numRemove = 1:n
        %numRemove
        % 初始化种群
        population = initializePopulation(d,n, populationSize, numRemove);

        % 记录最优解
        bestAreaReduction = -inf;
        bestSolution = [];

        for generation = 1:maxGenerations
            %generation
            % 评估种群
            fitness = evaluatePopulation(population, G, nodePositions, n, numRemove,area_0,populationSize);

            % 更新最优解
            [maxFitness, maxIdx] = max(fitness);
            if maxFitness > bestAreaReduction
                bestAreaReduction = maxFitness;
                bestSolution = population(maxIdx, :);
            end

            % 选择和交叉生成新一代种群
            newPopulation = selectionAndCrossover(population, fitness, populationSize, n, numRemove);

            % 变异
            newPopulation = mutatePopulation(newPopulation, mutationRate);

            % 更新种群
            population = newPopulation;
        end

        % 记录当前移除节点数的最优解
        removedNodes{numRemove} = find(bestSolution);
        %G_temp = G;
        %nodePositions_temp = nodePositions;
        %G_temp(removedNodes{numRemove}, :) = [];
        %G_temp(:, removedNodes{numRemove}) = [];
        %nodePositions_temp(removedNodes{numRemove}, :) = [];
        %area_ga(numRemove) = calculateLargestComponentCoverage(G_temp, nodePositions_temp);
        area_ga(numRemove) =area_0-bestAreaReduction;
        if area_ga(numRemove) == 0 && numRemove < n
            area_ga(numRemove+1:end) = 0;
            break;
        end
    end

    area_ga = area_ga / area_0;
    

end

function population = initializePopulation(d,n, populationSize, numRemove)
    % 初始化种群，每个个体是一个长度为n的二进制向量，且恰好有numRemove个1
    % d是节点的度向量
    
    % 按节点度值降序排序，获取排序后的索引
    [~, sortedIdx] = sort(d, 'descend');
    
    population = zeros(populationSize, n);
    
    % 第一个个体按节点度的顺序生成
    population(1, sortedIdx(1:numRemove)) = 1;
    
    % 剩余的个体随机生成
    for i = 2:populationSize
        idx = randperm(n, numRemove);
        population(i, idx) = 1;
    end
end



function fitness = evaluatePopulation(population, G, nodePositions, n, numRemove,area_0,populationSize)
    % 评估种群的适应度
    %populationSize = size(population, 1);
    fitness = zeros(populationSize, 1);
    for i = 1:populationSize
        solution = population(i, :);
        nodesToRemove = find(solution);
        G_temp = G;
        nodePositions_temp = nodePositions;
        G_temp(nodesToRemove, :) = [];
        G_temp(:, nodesToRemove) = [];
        nodePositions_temp(nodesToRemove, :) = [];
        fitness(i) = area_0 - calculateLargestComponentCoverage(G_temp, nodePositions_temp);
    end
end

function newPopulation = selectionAndCrossover(population, fitness, populationSize, n, numRemove, crossoverRate)
   crossoverRate=0.4; 
% 选择和交叉生成新一代种群
    newPopulation = zeros(populationSize, n);
    
    % 检查适应度是否全为零
    if all(fitness == 0)
        % 如果适应度全为零，随机选择父母
        for i = 1:populationSize
            parents = randsample(1:populationSize, 2); % 随机选择两个父母
            if numRemove > 1
                if rand < crossoverRate
                    crossoverPoint = randi([1, n-1]); % 随机选择一个交叉点
                    newIndividual = [population(parents(1), 1:crossoverPoint), population(parents(2), crossoverPoint+1:end)];
                else
                    newIndividual = population(parents(1), :); % 不进行交叉
                end
                newPopulation(i, :) = fixIndividual(newIndividual, numRemove);
            else
                newPopulation(i, :) = population(parents(1), :); % 只有一个节点时，不进行交叉
            end
        end
    else
        % 轮盘赌选择
        for i = 1:populationSize
            parents = randsample(1:populationSize, 2, true, fitness); % 轮盘赌选择两个父母
            if numRemove > 1
                if rand < crossoverRate
                    crossoverPoint = randi([1, n-1]); % 随机选择一个交叉点
                    newIndividual = [population(parents(1), 1:crossoverPoint), population(parents(2), crossoverPoint+1:end)];
                else
                    newIndividual = population(parents(1), :); % 不进行交叉
                end
                newPopulation(i, :) = fixIndividual(newIndividual, numRemove);
            else
                newPopulation(i, :) = population(parents(1), :); % 只有一个节点时，不进行交叉
            end
        end
    end
end

function fixedIndividual = fixIndividual(individual, numRemove)
    % 修正个体以确保其恰好有numRemove个1
    currentNumRemove = sum(individual);
    if currentNumRemove > numRemove
        % 如果1的数量超过numRemove，则将多余的1置为0
        onesIdx = find(individual == 1);
        zeroIdx = randsample(onesIdx, currentNumRemove - numRemove);
        individual(zeroIdx) = 0;
    elseif currentNumRemove < numRemove
        % 如果1的数量少于numRemove，则将0置为1
        zerosIdx = find(individual == 0);
        oneIdx = randsample(zerosIdx, numRemove - currentNumRemove);
        individual(oneIdx) = 1;
    end
    fixedIndividual = individual;
end


function mutatedPopulation = mutatePopulation(population, mutationRate)
    % 变异种群
    [populationSize, n] = size(population);
    mutatedPopulation = population;
    for i = 1:populationSize
        if rand < mutationRate
            % 随机选择两个位置进行变异
            mutationPoints = randperm(n, 2);
            % 确保变异后仍然有 numRemove 个1
            if mutatedPopulation(i, mutationPoints(1)) ~= mutatedPopulation(i, mutationPoints(2))
                mutatedPopulation(i, mutationPoints(1)) = 1 - mutatedPopulation(i, mutationPoints(1)); % 0变1，1变0
                mutatedPopulation(i, mutationPoints(2)) = 1 - mutatedPopulation(i, mutationPoints(2)); % 0变1，1变0
            end
        end
    end
end

